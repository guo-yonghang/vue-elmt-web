import{_ as e,o as n,d as o}from"./index-DSsaJ29a.js";const t={};function r(c,s,a,_,p,d){return n(),o("div",null,"warning")}const f=e(t,[["render",r]]);export{f as default};
