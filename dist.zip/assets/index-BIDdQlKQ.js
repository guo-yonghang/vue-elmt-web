import{_ as e,o as c,d as n}from"./index-DSsaJ29a.js";const o={};function r(s,t){return c(),n("div",null,"useBaseForm")}const _=e(o,[["render",r]]);export{_ as default};
