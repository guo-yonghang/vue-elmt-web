import{_ as e,o as n,d as o}from"./index-DSsaJ29a.js";const c={};function r(t,a){return n(),o("div",null,"information")}const _=e(c,[["render",r]]);export{_ as default};
