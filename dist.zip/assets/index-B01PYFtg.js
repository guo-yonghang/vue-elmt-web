import{_ as e,o,d as r}from"./index-DSsaJ29a.js";const t={};function n(c,s,a,_,p,d){return o(),r("div",null,"error")}const i=e(t,[["render",n]]);export{i as default};
