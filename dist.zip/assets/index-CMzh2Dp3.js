import{_ as e,o as s,d as c}from"./index-DSsaJ29a.js";const o={};function t(n,r,a,_,p,d){return s(),c("div",null,"success")}const i=e(o,[["render",t]]);export{i as default};
